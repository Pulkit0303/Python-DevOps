print("Hello World")

name = input("Enter your name:")
name = "DevOps" 
print("Hello",name,"!")

env = "Dev"
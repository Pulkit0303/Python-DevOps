print("\tWelcome to my calculator")

num1 = int(input("Enter a number: "))  #Type casting str->int
num2 = int(input("Enter a number: "))

print("Addition:",num1 + num2)
print("Difference:",num1 - num2)
print("Multiplication:",num1 * num2)

print(type(num1))
print(type(num2))